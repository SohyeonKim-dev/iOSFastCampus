//
//  ViewController.swift
//  quotesApp
//
//  Created by 김소현 on 2022/07/03.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var colorView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func tapChangeColorButton(_ sender: UIButton) {
        self.colorView.backgroundColor = UIColor.blue
        print("색상 변경 버튼이 클릭되었음 :) ")
        // 왜 컬러 뷰가 빌드 시에 표시가 안됨..?
    }
}

