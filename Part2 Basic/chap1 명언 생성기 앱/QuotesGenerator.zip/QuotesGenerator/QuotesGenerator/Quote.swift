//
//  Quote.swift
//  QuotesGenerator
//
//  Created by 김소현 on 2022/07/03.
//

import Foundation

struct Quote {
    let contents: String
    let name: String
}
