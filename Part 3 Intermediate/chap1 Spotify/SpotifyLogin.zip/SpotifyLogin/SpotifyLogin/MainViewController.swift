//
//  MainViewController.swift
//  SpotifyLogin
//
//  Created by 김소현 on 2022/07/15.
//

import UIKit
import Firebase
import FirebaseAuth

class MainViewController: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var resetPasswordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // pop 제스쳐로 뒤로 돌아가는 것이 불가능하다
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // 다시 네비게이션 바를 숨긴다! (true -> false -> true)
        navigationController?.navigationBar.isHidden = true
        
        let email = Auth.auth().currentUser?.email ?? "고객"
        // 만약에 없다면 고객이라고 표시한다. -> 왜?
        // ! 이메일이 없는 사람이라면 고객님이라고 표현하기 위해서!
        
        welcomeLabel.text =
        """
        환영합니다!
        \(email)님
        """
        
        let isEmailSignIn = Auth.auth().currentUser?.providerData[0].providerID == "password"
        // 해당 유저가 이메일로 가입한 유저 -> 변경 버튼 보이도록
        resetPasswordButton.isHidden = !isEmailSignIn
    }
    
    @IBAction func logoutButtonTapped(_ sender: UIButton) {
        // 로그인 뷰 컨트롤러로 넘어가도록
        
        let firebaseAuth = Auth.auth()
        
        do {
            try firebaseAuth.signOut()
            self.navigationController?.popToRootViewController(animated: true)
            // 에러가 발생하지 않으면, 버튼을 눌렀을 때 처음 화면으로 넘어가도록
            
        } catch let signOutError as NSError {
            print("ERROR: signout \(signOutError.localizedDescription)")
        }
        
    }
    
    @IBAction func resetPasswordButtonTapped(_ sender: UIButton) {
        let email = Auth.auth().currentUser?.email ?? ""
        Auth.auth().sendPasswordReset(withEmail: email, completion: nil)
        // 현재 사용자의 이메일로, 비밀번호를 reset하는 메일을 보낸다.
        // mail 안오는데?
    }
    
    @IBAction func profileUpdateButtonTapped(_ sender: UIButton) {
        let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
        changeRequest?.displayName = "브로콜리"
        // 이렇게 고정된 값이 아니라, uitextfield 등을 통해서 사용자가 입력한 값을 받아 update하는 것 추천
        changeRequest?.commitChanges { _ in
            let displayName = Auth.auth().currentUser?.displayName ?? Auth.auth().currentUser?.email ?? "고객"
            // 이름이 없다면 -> 이메일 -> 없다면? -> 고객
            
            self.welcomeLabel.text = """
            환영합니다.
            \(displayName)님
            """
        }
    }
}
