//
//  EnterEmailViewController.swift
//  SpotifyLogin
//
//  Created by 김소현 on 2022/07/15.
//

import UIKit
import Firebase
import FirebaseAuth

class EnterEmailViewController:UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!  // secure text entry
    @IBOutlet weak var errorMessageLabel: UILabel!
    @IBOutlet weak var nextButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nextButton.layer.cornerRadius = 30
        nextButton.isEnabled = false
        
        emailTextField.delegate = self
        passwordTextField.delegate = self
        // delegate를 self로 둔다는 게 무슨 의미?
        // extension 빼기 전에는 에러 발생한다. (상속 받으라고)
        
        // email 작성이 쉽도록, 처음 커서가 이곳에 있도록
        emailTextField.becomeFirstResponder()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = false 
    }
    
    @IBAction func nextButtonTapped(_ sender: UIButton) {
        // 다음 버튼을 누르는 순간 -> firebase auth에 정보를 넘긴다.
        let email = emailTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        
        // 신규 사용자 생성
        // 순환 참조 방지를 위한 [weak self]
        // 잘못된 입력을 처리하기 위하여, error도 함께 받음
        Auth.auth().createUser(withEmail: email, password: password){ [weak self] authResult, error in
            guard let self = self else {return}             // 무슨 의미인지 모르겠다
            
            if let error = error {
                let code = (error as NSError).code
                
                switch code {
                    
                case 17007: // 이미 가입한 계정 -> login
                    self.loginUser(withEmail: email, password: password)

                default:
                    self.errorMessageLabel.text = error.localizedDescription
                }
            } else {
                self.showMainViewController()
            }
        }
    }
    // 계정이 잘 생성되었다면, 메인 화면을 보여주어야 한다.
    private func showMainViewController () {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "MainViewController")
        // 이게 MVC 패턴?
        mainViewController.modalPresentationStyle = .fullScreen
        navigationController?.show(mainViewController, sender: nil)
    }
    
    private func loginUser(withEmail email: String, password: String){
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] _, error in
            guard let self = self else {return}      // 또 나왔다. 무슨 의미?
            
            if let error = error {
                self.errorMessageLabel.text = error.localizedDescription
            } else {
                self.showMainViewController()
            }
        }
    }
}

// extension으로 뺀다는 것?
// class인 EnterEmailViewController에서 -> UITextFieldDelegate를 상속받지 않고, 가독성을 위해 뒤로 extension에서 빼서 delegate를 상속받는다.
extension EnterEmailViewController: UITextFieldDelegate
{
    // 이메일, 비밀번호 입력 이후 return 버튼을 눌렀을 때, 키보드가 내려가도록
    // textFieldShouldReturn: 키보드 입력 이후 return 눌렀을 때
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        return false
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        let isEmailEmpty = emailTextField.text == ""
        let isPasswordEmpty = passwordTextField.text == ""
        nextButton.isEnabled = !isEmailEmpty && !isPasswordEmpty
        // 둘 다 찬다면, 버튼을 활성화시킨다.
    }
}
